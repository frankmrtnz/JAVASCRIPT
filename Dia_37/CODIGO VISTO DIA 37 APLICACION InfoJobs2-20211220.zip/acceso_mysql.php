<?php
    $con = mysqli_connect("mysql","usuario","1234567","InfoJobs2","3306") or die("ERROR CONEXION");
?>