var peliculas=[
{
id:1,
nombre:'Terminator',
descripcion:'Descripcion de la pelicula terminator',
imagen:'pelicula1.jpg',
tipo:'accion',
rating:12.5,
maximo_comentarios:10,
year:2019
},
{
id:2,
nombre:'John Wick 3',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula2.jpg',
tipo:'accion',
rating:8.5,
maximo_comentarios:8,
year:2019
},
{
id:3,
nombre:'Ocho apellidos vascos',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula3.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:3,
year:2016
},
{
id:4,
nombre:'Game over man!',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula4.jpg',
tipo:'comedia',
maximo_comentarios:2,
rating:12,
year:2012
},
{
id:5,
nombre:'Hazme reir',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula5.jpg',
tipo:'comedia',
maximo_comentarios:1,
rating:2.5,
year:2011
},
{
id:6,
nombre:'Resacon en las vegas',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula6.jpg',
tipo:'comedia',
rating:12,
maximo_comentarios:12,
year:2011
},
{
id:7,
nombre:'Las invisibles',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula7.jpg',
tipo:'comedia',
rating:7,
maximo_comentarios:12,
year:2014
},
{
id:8,
nombre:'El bosque maldito',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula8.jpg',
tipo:'terror',
rating:7.5,
maximo_comentarios:12,
year:2013
},
{
id:9,
nombre:'El ultimatun de Bourne',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula9.jpg',
tipo:'accion',
rating:4.5,
maximo_comentarios:12,
year:2001
},
{
id:10,
nombre:'La noche de Halloween',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula10.jpg',
tipo:'terror',
rating:12.5,
maximo_comentarios:12,
year:2019
},
{
id:11,
nombre:'Lobezno',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula11.jpg',
tipo:'accion',
rating:6.5,
maximo_comentarios:12,
year:2016
},
{
id:12,
nombre:'American Pie',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula12.jpg',
tipo:'comedia',
rating:10.5,
maximo_comentarios:12,
year:2008
},
{
id:13,
nombre:'Taxi a gibraltar',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula13.jpg',
tipo:'comedia',
rating:1.5,
maximo_comentarios:12,
year:2003
},
{
id:14,
nombre:'Virgen a los cuarenta',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula14.jpg',
tipo:'comedia',
rating:3.5,
maximo_comentarios:12,
year:2016
},
{
id:16,
nombre:'Novio por una noche',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula16.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:15,
nombre:'Primos',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula15.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:20,
nombre:'La boda de mi mejor amiga',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula20.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:19,
nombre:'Epic movie',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula19.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:18,
nombre:'Los padres de ella',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula18.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:17,
nombre:'Bajo el mismo techo',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula17.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:21,
nombre:'El exorcista',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula21.jpg',
tipo:'terror',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:22,
nombre:'Sinister',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula22.jpg',
tipo:'terror',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:24,
nombre:'El conjuro',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula24.jpg',
tipo:'terror',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:23,
nombre:'Resident Evil',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula23.jpg',
tipo:'accion',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:25,
nombre:'Extranjero',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula25.jpg',
tipo:'accion',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:26,
nombre:'Insomnia',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula26.jpg',
tipo:'terror',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:28,
nombre:'Saw',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula28.jpg',
tipo:'terror',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:27,
nombre:'SuperC',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula27.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:29,
nombre:'Tom Raider',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula29.jpg',
tipo:'accion',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:30,
nombre:'Calles de fuego',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula30.jpg',
tipo:'accion',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:31,
nombre:'Fast & Furious',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula31.jpg',
tipo:'accion',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:34,
nombre:'Spy',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula34.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:44,
nombre:'Annabelle',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula44.jpg',
tipo:'terror',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:45,
nombre:'MIB',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula45.jpg',
tipo:'comedia',
rating:12.5,
maximo_comentarios:12,
year:2016
},
{
id:46,
nombre:'Black Panther',
descripcion:'Descripcion de la pelicula',
imagen:'pelicula46.jpg',
tipo:'accion',
rating:12.5,
maximo_comentarios:12,
year:2016
}
]
var opiniones=[
{
id:1,
likes:3,
dislikes:9
},
{
id:2,
likes:13,
dislikes:9
},
{
id:3,
likes:8,
dislikes:9
},
{
id:4,
likes:3,
dislikes:0
},
{
id:5,
likes:23,
dislikes:19
},
{
id:6,
likes:3,
dislikes:2
},
{
id:7,
likes:0,
dislikes:0
},
{
id:8,
likes:33,
dislikes:9
},
{
id:9,
likes:43,
dislikes:9
},
{
id:10,
likes:53,
dislikes:9
},
{
id:11,
likes:63,
dislikes:9
},
{
id:12,
likes:13,
dislikes:9
},
{
id:13,
likes:13,
dislikes:9
},
{
id:14,
likes:2,
dislikes:9
},
{
id:16,
likes:14,
dislikes:9
},
{
id:15,
likes:83,
dislikes:9
},
{
id:20,
likes:3,
dislikes:29
},
{
id:19,
likes:23,
dislikes:9
},
{
id:18,
likes:9,
dislikes:9
},
{
id:17,
likes:3,
dislikes:9
},
{
id:21,
likes:3,
dislikes:9
},
{
id:22,
likes:93,
dislikes:9
},
{
id:24,
likes:3,
dislikes:99
},
{
id:23,
likes:1,
dislikes:9
},
{
id:25,
likes:3,
dislikes:9
},
{
id:26,
likes:3,
dislikes:9
},
{
id:28,
likes:3,
dislikes:9
},
{
id:27,
likes:3,
dislikes:9
},
{
id:29,
likes:3,
dislikes:9
},
{
id:30,
likes:3,
dislikes:9
},
{
id:31,
likes:3,
dislikes:9
},
{
id:34,
likes:3,
dislikes:9
},
{
id:44,
likes:3,
dislikes:9
},
{
id:45,
likes:3,
dislikes:9
},
{
id:46,
likes:3,
dislikes:9
}
]